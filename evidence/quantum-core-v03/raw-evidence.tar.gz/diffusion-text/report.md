# Quantum-memory denoising comparison

Gate-only numerical model; raw-record loading; no classical optimizer or fitted conditional-table gates.

Corpus: bundled_small_English_text. Training records: 48; held-out records: 16; evaluated: 4.
Classical direct-table top-1: 0.5000; unseen contexts: 2.

| Steps | Noiseless correct-token | Noisy correct-token | Classical matched channel |
|---:|---:|---:|---:|
| 0 | 0.0000 | 0.0000 | 0.0000 |
| 1 | 0.3178 | 0.2671 | 0.3250 |
| 3 | 0.4751 | 0.3851 | 0.4786 |

Postselection, abstentions, repeated contexts and circuit resources are retained in JSON. 
This is neither a full trained diffusion language model nor a full quantum host pipeline.
