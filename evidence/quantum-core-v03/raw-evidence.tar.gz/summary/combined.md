# QCeNN-QML measured experiment summary

Each result refers to quantum circuits simulated using Qiskit Aer, not physical quantum hardware.

## Quantum text memory

- Generated text: ran on.
- Vocabulary: 10 tokens, 38 qubits.
- Classical SmolLM2-135M teacher used: False.
- Not the SmolLM2-135M pretrained transformer on a quantum device.

## Quantum masked-token denoising

- Train/test sizes: 48/16; evaluated cases: 4.
- Engineered masking beta=1.0; reverse collision eta=0.65.
| Steps | Measured correct-token fraction | Ideal channel expectation |
|---:|---:|---:|
| 0 | 0.0000 | 0.0000 |
| 1 | 0.2671 | 0.3250 |
| 3 | 0.3851 | 0.4786 |

- Not a trained quantum diffusion LLM or a reproduced upstream QCeNN-MI solver.

## Readout bit-flip noise comparison

- Simulated readout error per measured bit: 0.05.
| Steps | Measured clean-token frequency (noisy) | Ideal-readout result |
|---:|---:|---:|
| 0 | 0.0000 | 0.0000 |
| 1 | 0.2671 | 0.3178 |
| 3 | 0.3851 | 0.4751 |

Readout flips are a measurement-error model, not a beneficial denoising resource.

## Quantum-memory MNIST

- Tiny training fit gate required: True.
- Mean evaluated test accuracy: 0.2.
- Nonparametric quantum exemplar memory, with no classical optimizer.

## Reversible quantum attention

- Measured component cases: 2.
- Signed ternary dot products and softmax sampling are computed in gates.
- Full pretrained Smol attention blocks and coherent full-precision vector output are unimplemented.

## Full Smol feasibility status

- Status: NOT_IMPLEMENTED_NOT_DEMONSTRATED.
- Explicit resident basis-encoding weight qubits: 2152240128.
- This is an encoding estimate, not a lower bound on all quantum implementations.

## Experiments not executed here

- artifacts/quantum-core-evidence/not-run-legacy-mnist.json

## Conclusion

All experiments are feasibility demonstrations. They do not establish speedup, advantage, physically executed noise benefits, or a full 135M-parameter quantum language model.
