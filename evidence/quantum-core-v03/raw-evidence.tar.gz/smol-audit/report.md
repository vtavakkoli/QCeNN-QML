# SmolLM2-135M quantum feasibility audit

**Full pretrained model conversion: not implemented or demonstrated.**

Actual configuration: 30 layers, width 576, vocabulary 49152.

Parameter count from shapes: 134,515,008. A 16-bit resident basis encoding would use 2,152,240,128 logical weight qubits, before workspace/error correction. This is one encoding estimate, not an impossibility theorem.

Dense projections and MLPs require 106,168,320 scalar MACs per token, before context attention, nonlinearities, normalization, data access and readout.

The tested quantum component computes small signed dot products and softmax attention samples. It does not execute Smol weights or produce a coherent full-precision hidden vector.

Source: https://huggingface.co/HuggingFaceTB/SmolLM2-135M/raw/main/config.json
